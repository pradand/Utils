//
//  ContentView.swift
//  PoCOne
//
//  Created by C648309 on 14/12/2023.
//

import SwiftUI

struct ListView: View {
    var body: some View {
//        VStack {
//            Image(systemName: "globe")
//                .imageScale(.large)
//                .foregroundStyle(.tint)
//            Text("Hello, world!")
//        }
//        .padding()
        NavigationView {
            ScrollView(.vertical, showsIndicators: false) {
                VStack(alignment: .leading, spacing: .zero) {
                    TableViewCell(text: "Demo Cell 1", displayDivider: true)
                    TableViewCell(text: "Demo Cell 2", displayDivider: true)
                    TableViewCell(text: "Demo Cell 2", displayDivider: true)
                    TableViewCell(text: "Demo Cell 2", displayDivider: true)
                    TableViewCell(text: "Demo Cell 2", displayDivider: true)
                    TableViewCell(text: "Demo Cell 2", displayDivider: true)
                    TableViewCell(text: "Demo Cell 2", displayDivider: true)
                    TableViewCell(text: "Demo Cell 2", displayDivider: true)
                }
            }
            .navigationTitle(Text("Sample App"))
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    ListView()
}


class ListViewModel: ObservableObject {
    
}
