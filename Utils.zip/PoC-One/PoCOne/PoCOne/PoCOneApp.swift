//
//  PoCOneApp.swift
//  PoCOne
//
//  Created by C648309 on 14/12/2023.
//

import SwiftUI

@main
struct PoCOneApp: App {
    var body: some Scene {
        WindowGroup {
            ListView()
        }
    }
}
