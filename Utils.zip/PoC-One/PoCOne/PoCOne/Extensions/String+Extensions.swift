//
//  String+Extensions.swift
//  PoCOne
//
//  Created by C648309 on 14/12/2023.
//

import Foundation

extension String {
    func localized(tableName: String, bundle: Bundle = .main, arguments: [CVarArg] = []) -> String {
        String(format: NSLocalizedString(self, tableName: tableName, bundle: bundle, comment: ""), arguments: arguments)
    }

    func localized(tableName: String, bundle: Bundle = .main, arguments: CVarArg...) -> String {
        String(format: NSLocalizedString(self, tableName: tableName, bundle: bundle, comment: ""), arguments: arguments)
    }
}
