//
//  Image+Extensions.swift
//  PoCOne
//
//  Created by C648309 on 14/12/2023.
//

import SwiftUI

extension Image {
    static func namedImage(_ named: NamedImageProtocol) -> Image {
        .init(named.literal, bundle: named.bundle)
    }

    static func namedSystemImage(_ named: NamedSystemImageProtocol) -> Image {
        .init(systemName: named.literal)
    }
}
