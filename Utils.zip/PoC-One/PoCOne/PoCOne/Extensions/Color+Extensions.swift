//
//  Color+Extensions.swift
//  PoCOne
//
//  Created by C648309 on 14/12/2023.
//

import SwiftUI

extension Color {
    static func namedColor(_ named: NamedColorProtocol) -> Color {
        .init(named.literal, bundle: named.bundle)
    }
}
