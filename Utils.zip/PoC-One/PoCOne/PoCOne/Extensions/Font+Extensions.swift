//
//  Font+Extensions.swift
//  PoCOne
//
//  Created by C648309 on 14/12/2023.
//

import SwiftUI

extension Font {
    static func namedFont(_ named: NamedFontProtocol, size: CGFloat) -> Font {
        Font.custom(named.literal, size: size)
    }

    static func namedFont(_ named: NamedFontProtocol, size: NamedSizeProtocol) -> Font {
        Font.custom(named.literal, size: size.literal)
    }

    /// Roboto
    static var robotoSmall: Font {
        .namedFont(Fonts.roboto, size: FontSizes.small)
    }

    static var robotoXSmall: Font {
        .namedFont(Fonts.roboto, size: FontSizes.xSmall)
    }

    static var robotoMedium: Font {
        .namedFont(Fonts.roboto, size: FontSizes.medium)
    }

    static var robotoXMedium: Font {
        .namedFont(Fonts.roboto, size: FontSizes.xMedium)
    }

    static var robotoLarge: Font {
        .namedFont(Fonts.roboto, size: FontSizes.large)
    }

    static var robotoXLarge: Font {
        .namedFont(Fonts.roboto, size: FontSizes.xLarge)
    }

    static var robotoXXLarge: Font {
        .namedFont(Fonts.roboto, size: FontSizes.xxLarge)
    }

    /// SF Pro Text
    static var sfProTextSmall: Font {
        .namedFont(Fonts.sfProText, size: FontSizes.small)
    }

    static var sfProTextXSmall: Font {
        .namedFont(Fonts.sfProText, size: FontSizes.xSmall)
    }

    static var sfProTextMedium: Font {
        .namedFont(Fonts.sfProText, size: FontSizes.medium)
    }

    static var sfProTextXMedium: Font {
        .namedFont(Fonts.sfProText, size: FontSizes.xMedium)
    }

    static var sfProTextLarge: Font {
        .namedFont(Fonts.sfProText, size: FontSizes.large)
    }

    static var sfProTextXLarge: Font {
        .namedFont(Fonts.sfProText, size: FontSizes.xLarge)
    }

    static var sfProTextXXLarge: Font {
        .namedFont(Fonts.sfProText, size: FontSizes.xxLarge)
    }

    /// SF Pro Display
    static var sfProDisplaySmall: Font {
        .namedFont(Fonts.sfProDisplay, size: FontSizes.small)
    }

    static var sfProDisplayXSmall: Font {
        .namedFont(Fonts.sfProDisplay, size: FontSizes.xSmall)
    }

    static var sfProDisplayMedium: Font {
        .namedFont(Fonts.sfProDisplay, size: FontSizes.medium)
    }

    static var sfProDisplayXMedium: Font {
        .namedFont(Fonts.sfProDisplay, size: FontSizes.xMedium)
    }

    static var sfProDisplayLarge: Font {
        .namedFont(Fonts.sfProDisplay, size: FontSizes.large)
    }

    static var sfProDisplayXLarge: Font {
        .namedFont(Fonts.sfProDisplay, size: FontSizes.xLarge)
    }

    static var sfProDisplayXXLarge: Font {
        .namedFont(Fonts.sfProDisplay, size: FontSizes.xxLarge)
    }
}
