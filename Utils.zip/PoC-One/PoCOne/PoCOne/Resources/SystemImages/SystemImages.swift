//
//  SystemImages.swift
//  PoCOne
//
//  Created by C648309 on 14/12/2023.
//

import Foundation

protocol NamedSystemImageProtocol {
    var literal: String { get }
}

enum SystemImages: String, NamedSystemImageProtocol, CaseIterable {
    case xmarkCircle = "xmark.circle"
    case chevronRight = "chevron.right"
    case magnifyingGlass = "magnifyingglass"
    case xMark = "xmark"
    case locationCircle = "location.circle"
    case clock = "clock"
    case mappinCircle = "mappin.circle"
    case minus = "minus"
    case plus = "plus"
    case locationFill = "location.fill"
    case exclamationmarkCircle = "exclamationmark.circle"
    case listBullet = "list.bullet"
    case map = "map"
    case infoCircle = "info.circle"
    case notMapped

    var literal: String {
        self.rawValue
    }

    init(from decoder: Decoder) throws {
        self = try SystemImages(rawValue: decoder.singleValueContainer().decode(RawValue.self)) ?? .notMapped
    }
}
