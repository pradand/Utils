//
//  Strings.swift
//  PoCOne
//
//  Created by C648309 on 20/12/2023.
//

import Foundation

enum Strings {
    enum Localized: String, Localizable {
        case title
        case subtitle

        var tableName: String {
            "Strings"
        }
    }
}
