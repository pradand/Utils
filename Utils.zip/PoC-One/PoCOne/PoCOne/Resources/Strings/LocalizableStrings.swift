//
//  LocalizableStrings.swift
//  PoCOne
//
//  Created by C648309 on 20/12/2023.
//

import Foundation

protocol Localizable {
    var tableName: String { get }
    var bundle: Bundle { get }

    func string(_ arguments: [CVarArg]) -> String
    func string(_ arguments: CVarArg...) -> String
}

extension Localizable where Self: RawRepresentable, Self.RawValue == String {
    var bundle: Bundle {
        .main
    }

    func string(_ arguments: [CVarArg] = []) -> String {
        rawValue.localized(tableName: tableName, bundle: bundle, arguments: arguments)
    }

    func string(_ arguments: CVarArg...) -> String {
        rawValue.localized(tableName: tableName, bundle: bundle, arguments: arguments)
    }
}
