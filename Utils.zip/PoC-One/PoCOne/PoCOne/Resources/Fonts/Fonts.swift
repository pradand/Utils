//
//  Fonts.swift
//  PoCOne
//
//  Created by C648309 on 14/12/2023.
//

import Foundation

protocol NamedFontProtocol {
    var literal: String { get }
}

enum Fonts: String, NamedFontProtocol, CaseIterable {
    case roboto = "Roboto"
    case sfProText = "SF Pro Text"
    case sfProDisplay = "SF Pro Display"

    var literal: String {
        self.rawValue
    }
}
