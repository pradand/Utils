//
//  FontSizes.swift
//  PoCOne
//
//  Created by C648309 on 14/12/2023.
//

import Foundation

protocol NamedSizeProtocol {
    var literal: CGFloat { get }
}

enum FontSizes: CGFloat, NamedSizeProtocol, CaseIterable {
    case small = 12
    case xSmall = 13
    case medium = 14
    case xMedium = 15
    case large = 16
    case xLarge = 17
    case xxLarge = 22

    var literal: CGFloat {
        self.rawValue
    }
}
