//
//  Images.swift
//  PoCOne
//
//  Created by C648309 on 14/12/2023.
//

import Foundation

protocol NamedImageProtocol {
    var bundle: Bundle { get }
    var literal: String { get }
}

enum Images: String, NamedImageProtocol, CaseIterable {
    case cvsHeartFilled = "cvsHeart-filled"
    case cvsHeart

    var bundle: Bundle {
        .main
    }

    var literal: String {
        self.rawValue
    }
}
