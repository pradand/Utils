//
//  HeaderView.swift
//  PoCOne
//
//  Created by C648309 on 20/12/2023.
//

import SwiftUI

struct HeaderView: View {
    let text: String
    let displayDivider: Bool

    init(text: String, displayDivider: Bool = true) {
        self.text = text
        self.displayDivider = displayDivider
    }

    var body: some View {
        VStack(alignment: .leading, spacing: .zero) {
            Text(text)
                .font(.system(size: 13, weight: .regular))
                .foregroundColor(.gray)
                .padding(.horizontal, 5)
                .padding(.top, 32)
                .padding(.bottom, 8)
                .frame(maxWidth: .infinity, alignment: .leading)
            dividerBuilder
        }
        .padding(.horizontal, 5)
    }
}

private extension HeaderView {
    @ViewBuilder
    var dividerBuilder: some View {
        if displayDivider {
            Divider()
        }
    }
}

#Preview {
    HeaderView(text: "Demo Header")
}
