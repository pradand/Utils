//
//  TableViewCell.swift
//  PoCOne
//
//  Created by C648309 on 14/12/2023.
//

import SwiftUI

struct TableViewCell: View {
    private let text: String
    private let displayDivider: Bool

    init(text: String, displayDivider: Bool = true) {
        self.text = text
        self.displayDivider = displayDivider
    }

    var body: some View {
        VStack(alignment: .leading, spacing: .zero) {
            Text(text)
                .font(.system(size: 17, weight: .regular))
                .foregroundColor(.black)
                .padding(.leading, 25)
                .padding(.trailing, 15)
                .padding(.vertical, 16)
            dividerBuilder
        }
        .padding(.horizontal, 5)
    }
}

private extension TableViewCell {
    @ViewBuilder
    var dividerBuilder: some View {
        if displayDivider {
            Divider()
        }
    }
}

#Preview {
    VStack {
        TableViewCell(text: "Demo Cell 1", displayDivider: true)
        TableViewCell(text: "Demo Cell 2", displayDivider: true)
    }
}
