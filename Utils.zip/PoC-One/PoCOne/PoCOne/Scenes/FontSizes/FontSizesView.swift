//
//  FontSizesView.swift
//  PoCOne
//
//  Created by C648309 on 20/12/2023.
//

import SwiftUI

struct FontSizesView: View {
    var body: some View {
        ScrollView(.vertical, showsIndicators: false) {
            VStack(alignment: .leading, spacing: .zero) {
                makeView(for: .namedFont(Fonts.roboto, size: FontSizes.small), literal: "Roboto small")
                makeView(for: .robotoXSmall, literal: "Roboto xSmall")
                makeView(for: .namedFont(Fonts.roboto, size: FontSizes.medium), literal: "Roboto medium")
                makeView(for: .robotoXMedium, literal: "Roboto xMedium")
                makeView(for: .namedFont(Fonts.roboto, size: FontSizes.large), literal: "Roboto large")
                makeView(for: .namedFont(Fonts.roboto, size: FontSizes.xLarge), literal: "Roboto xLarge")
                makeView(for: .robotoXXLarge, literal: "Roboto XXLarge")
                
                makeView(for: .namedFont(Fonts.sfProText, size: 18), literal: "SF Pro Text")
                makeView(for: .namedFont(Fonts.sfProDisplay, size: 16), literal: "SF Pro Display")
            }
        }
        .navigationBarTitleDisplayMode(.inline)
    }
}

private extension FontSizesView {
    func makeView(for font: Font, literal: String) -> some View {
        RoundedRectangle(cornerRadius: 15)
            .foregroundColor(.accentColor)
            .frame(height: 100)
            .overlay {
                Text(literal)
                    .foregroundStyle(.white)
                    .font(font)
            }
            .padding(.vertical, 2)
            .padding(.horizontal, 8)
    }
}

#Preview {
    FontSizesView()
}
