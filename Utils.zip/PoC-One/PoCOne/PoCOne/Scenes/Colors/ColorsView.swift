//
//  ColorsView.swift
//  PoCOne
//
//  Created by C648309 on 20/12/2023.
//

import SwiftUI

struct ColorsView: View {
    var body: some View {
        ScrollView(.vertical, showsIndicators: false) {
            VStack(alignment: .leading, spacing: .zero) {
                ForEach(Colors.allCases, id: \.self) { color in
                    makeView(for: color)
                }
            }
        }
        .navigationBarTitleDisplayMode(.inline)
    }
}

private extension ColorsView {
    func makeView(for color: Colors) -> some View {
        RoundedRectangle(cornerRadius: 15)
            .foregroundColor(.namedColor(color))
            .frame(height: 100)
            .overlay {
                Text(color.literal)
                    .foregroundStyle(.white)
            }
            .padding(.vertical, 2)
            .padding(.horizontal, 8)
    }
}

#Preview {
    ColorsView()
}
