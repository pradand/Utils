//
//  SystemImagesView.swift
//  PoCOne
//
//  Created by C648309 on 20/12/2023.
//

import SwiftUI

struct SystemImagesView: View {
    private let colors: [Color] = [.green, .blue, .purple, .orange, .namedColor(Colors.heavyYellow)]
    var body: some View {
        ScrollView(.vertical, showsIndicators: false) {
            VStack(alignment: .leading, spacing: .zero) {
                ForEach(SystemImages.allCases.filter({ $0 != .notMapped }), id: \.self) { image in
                    makeView(for: image, foregroundColor: colors.randomElement() ?? .yellow)
                }
            }
        }
        .navigationBarTitleDisplayMode(.inline)
    }
}

private extension SystemImagesView {
    func makeView(for image: SystemImages, foregroundColor: Color) -> some View {
        RoundedRectangle(cornerRadius: 15)
            .foregroundColor(foregroundColor)
            .frame(height: 100)
            .overlay {
                HStack(alignment: .center, spacing: 10) {
                    Image.namedSystemImage(image)
                        .padding(.leading, 10)
                    Text(image.literal)
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
            .padding(.vertical, 2)
            .padding(.horizontal, 8)
    }
}

#Preview {
    SystemImagesView()
}
