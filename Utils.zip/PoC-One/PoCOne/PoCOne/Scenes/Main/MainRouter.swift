//
//  MainRouter.swift
//  PoCOne
//
//  Created by C648309 on 20/12/2023.
//

import SwiftUI

protocol MainRoutingLogic {
    func routeTo(destination: Main.Sections) -> AnyView
}

struct MainRouter: MainRoutingLogic {
    func routeTo(destination: Main.Sections) -> AnyView {
        switch destination {
        case .color:
            return AnyView(ColorsView().navigationTitle(destination.header))
        case .image:
            return AnyView(ImagesView().navigationTitle(destination.header))
        case .systemImage:
            return AnyView(SystemImagesView().navigationTitle(destination.header))
        case .font:
            return AnyView(FontSizesView().navigationTitle(destination.header))
        case .fontSize:
            return AnyView(EmptyView().navigationTitle(destination.header))
        case .string:
            return AnyView(EmptyView().navigationTitle(destination.header))
        }
    }
}
