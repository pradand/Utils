//
//  MainModels.swift
//  PoCOne
//
//  Created by C648309 on 20/12/2023.
//

import Foundation

enum Main {
    enum Sections: Int, Hashable, CaseIterable {
        case color
        case image
        case systemImage
        case font
        case fontSize
        case string

        enum ColorCells: String, Hashable, CaseIterable {
            case customDarkGrey = "Custom Dark Grey"
            case heavyYellow = "Heavy Yellow"
        }

        enum ImageCells: String, Hashable, CaseIterable {
            case cvsHeartFilled = "CVS Heart Filled"
            case cvsHeart = "CVS Heart"
        }

        enum SystemImageCells: String, Hashable, CaseIterable {
            case xmarkCircle = "xmark circle"
            case chevronRight = "chevron right"
            case magnifyingGlass = "magnifyingglass"
            case xMark = "xmark"
            case locationCircle = "location circle"
            case clock = "clock"
            case mappinCircle = "mappin circle"
            case minus = "minus"
            case plus = "plus"
            case locationFill = "location fill"
            case exclamationmarkCircle = "exclamationmark circle"
            case listBullet = "list bullet"
            case map = "map"
            case infoCircle = "info circle"
        }

        enum FontCells: String, Hashable, CaseIterable {
            case roboto = "Roboto"
            case sfProText = "SF Pro Text"
            case sfProDisplay = "SF Pro Display"
        }

        enum FontSizeCells: String, Hashable, CaseIterable {
            case small = "12"
            case xSmall = "13"
            case medium = "14"
            case xMedium = "15"
            case large = "16"
            case xLarge = "17"
            case xxLarge = "22"
        }

        enum StringCells: String, Hashable, CaseIterable {
            case sampleText = "Sample Text"
            case textWithSingleArgument = "Text with Single Argument"
        }

        var header: String {
            switch self {
            case .color:
                return "Colors"
            case .image:
                return "Images"
            case .systemImage:
                return "System Images"
            case .font:
                return "Fonts"
            case .fontSize:
                return "Font Sizes"
            case .string:
                return "Strings"
            }
        }

        var allRows: [String] {
            switch self {
            case .color:
                return ColorCells.allCases.map({ $0.rawValue })
            case .image:
                return ImageCells.allCases.map({ $0.rawValue })
            case .systemImage:
                return SystemImageCells.allCases.map({ $0.rawValue })
            case .font:
                return FontCells.allCases.map({ $0.rawValue })
            case .fontSize:
                return FontSizeCells.allCases.map({ $0.rawValue })
            case .string:
                return StringCells.allCases.map({ $0.rawValue })
            }
        }
    }
}
