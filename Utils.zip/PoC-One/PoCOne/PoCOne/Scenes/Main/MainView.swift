//
//  MainView.swift
//  PoCOne
//
//  Created by C648309 on 20/12/2023.
//

import SwiftUI

struct MainView<Router: MainRoutingLogic>: View {
    var mainRouter: Router

    var body: some View {
        NavigationView {
            ScrollView(.vertical, showsIndicators: false) {
                VStack(alignment: .leading, spacing: .zero) {
                    ForEach(Main.Sections.allCases, id: \.self) { section in
                        HeaderView(text: section.header.uppercased())
                        cells(for: section)
                    }
                }
            }
            .navigationTitle(Text("Sample App"))
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

private extension MainView {
    func cells(for section: Main.Sections) -> some View {
        ForEach(section.allRows, id: \.self) { title in
            cell(section: section, title: title)
        }
    }

    func cell(section: Main.Sections, title: String) -> some View {
        NavigationLink {
            mainRouter.routeTo(destination: section)
        } label: {
            TableViewCell(text: title)
        }
    }
}

#Preview {
    MainView(mainRouter: MainRouter())
}
