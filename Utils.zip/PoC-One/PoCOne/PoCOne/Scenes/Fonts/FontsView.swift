//
//  FontsView.swift
//  PoCOne
//
//  Created by C648309 on 20/12/2023.
//

import SwiftUI

struct FontsView: View {
    var body: some View {
        ScrollView(.vertical, showsIndicators: false) {
            VStack(alignment: .leading, spacing: .zero) {
                ForEach(Fonts.allCases, id: \.self) { font in
                    makeView(for: font)
                }
            }
        }
        .navigationBarTitleDisplayMode(.inline)
    }
}

private extension FontsView {
    func makeView(for font: Fonts) -> some View {
        RoundedRectangle(cornerRadius: 15)
            .foregroundColor(.accentColor)
            .frame(height: 100)
            .overlay {
                Text(font.literal)
                    .foregroundStyle(.white)
                    .font(.namedFont(font, size: 19))
            }
            .padding(.vertical, 2)
            .padding(.horizontal, 8)
    }
}

#Preview {
    FontsView()
}
