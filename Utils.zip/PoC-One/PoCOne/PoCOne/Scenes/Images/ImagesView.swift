//
//  ImagesView.swift
//  PoCOne
//
//  Created by C648309 on 20/12/2023.
//

import SwiftUI

struct ImagesView: View {
    var body: some View {
        ScrollView(.vertical, showsIndicators: false) {
            VStack(alignment: .leading, spacing: .zero) {
                ForEach(Images.allCases, id: \.self) { image in
                    makeView(for: image)
                }
            }
        }
        .navigationBarTitleDisplayMode(.inline)
    }
}

private extension ImagesView {
    func makeView(for image: Images) -> some View {
        RoundedRectangle(cornerRadius: 15)
            .foregroundColor(.green)
            .frame(height: 100)
            .overlay {
                HStack(alignment: .center, spacing: 10) {
                    Image.namedImage(image)
                        .padding(.leading, 10)
                    Text(image.literal)
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
            .padding(.vertical, 2)
            .padding(.horizontal, 8)
    }
}

#Preview {
    ImagesView()
}
