# frozen_string_literal: true

module RBS
  VERSION = "3.4.0"
end
