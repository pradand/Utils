# frozen_string_literal: true

module RBS
  VERSION = "3.8.0"
end
