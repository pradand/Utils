#ifndef RBS_H
#define RBS_H

#include "rbs/constants.h"
#include "rbs/ruby_objs.h"

#endif
